import 'dotenv/config';
import { createClient } from '@supabase/supabase-js';

// Conecta no banco de dados do Supabase usando as chaves secretas
export const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_KEY
);
