import express from 'express';
import { supabase } from '../db.js';

const router = express.Router();

// Criar nova reserva
router.post('/', async (req, res) => {
    try {
        const reservation = req.body;

        // Calcula comissão da reserva
        reservation.commission = reservation.total_price * 0.1;

        const { data, error } = await supabase
            .from('reservations')
            .insert([reservation])
            .select();

        if (error) throw error;
        res.status(201).json(data[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Listar reservas
router.get('/', async (req, res) => {
    const { data, error } = await supabase.from('reservations').select('*');
    if (error) return res.status(500).json({ error: error.message });
    res.json(data);
});

export default router;
