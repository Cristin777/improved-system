import express from 'express';
import { supabase } from '../db.js';

const router = express.Router();

// Criar um novo imóvel
router.post('/', async (req, res) => {
    try {
        const property = req.body;
        property.commission = property.type === 'venda'
            ? property.price * 0.05
            : property.price * 0.10;

        const { data, error } = await supabase
            .from('properties')
            .insert([property])
            .select();

        if (error) throw error;
        res.status(201).json(data[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Listar imóveis
router.get('/', async (req, res) => {
    const { data, error } = await supabase.from('properties').select('*');
    if (error) return res.status(500).json({ error: error.message });
    res.json(data);
});

export default router;
