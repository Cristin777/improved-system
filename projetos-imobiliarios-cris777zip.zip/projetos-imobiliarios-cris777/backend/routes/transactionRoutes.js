import express from 'express';
import { supabase } from '../db.js';

const router = express.Router();

// Criar nova transação financeira
router.post('/', async (req, res) => {
    try {
        const transaction = req.body;

        const { data, error } = await supabase
            .from('transactions')
            .insert([transaction])
            .select();

        if (error) throw error;
        res.status(201).json(data[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Listar transações
router.get('/', async (req, res) => {
    const { data, error } = await supabase.from('transactions').select('*');
    if (error) return res.status(500).json({ error: error.message });
    res.json(data);
});

// Resumo financeiro (entradas, saídas, saldo)
router.get('/summary', async (req, res) => {
    try {
        const { data, error } = await supabase.from('transactions').select('*');
        if (error) throw error;

        const entradas = data
            .filter(t => t.type === 'entrada')
            .reduce((acc, t) => acc + Number(t.amount || 0), 0);

        const saídas = data
            .filter(t => t.type === 'saida')
            .reduce((acc, t) => acc + Number(t.amount || 0), 0);

        res.json({
            entradas,
            saídas,
            saldo: entradas - saídas
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

export default router;
