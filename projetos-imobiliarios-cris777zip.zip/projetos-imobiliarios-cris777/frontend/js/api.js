// Caminho base para o backend
const API_BASE = window.location.origin;

// Teste de conexão ao carregar qualquer página
console.log("Conectando ao backend em:", API_BASE);
